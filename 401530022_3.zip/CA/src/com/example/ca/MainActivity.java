package com.example.ca;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {

	TextView t1,t2,warn,stf;
	Button eq,pl,s,mu,de,point,clear,b1,b2,b3,b4,b5,b6,b7,b8,b9,b0;
	String NU1="0" , NU2="0" ;
	int Cal_index=0;
	int Index_Value=0;

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		init();
		setc();
	}
	
	private void setc() {
		b0.setOnClickListener(MyOnClick);
		b1.setOnClickListener(MyOnClick);		
		b2.setOnClickListener(MyOnClick);		
		b3.setOnClickListener(MyOnClick);		
		b4.setOnClickListener(MyOnClick);		
		b5.setOnClickListener(MyOnClick);		
		b6.setOnClickListener(MyOnClick);		
		b7.setOnClickListener(MyOnClick);		
		b8.setOnClickListener(MyOnClick);		
		b9.setOnClickListener(MyOnClick);		
		pl.setOnClickListener(MyOnClick);		
		eq.setOnClickListener(MyOnClick);		
		de.setOnClickListener(MyOnClick);		
		s.setOnClickListener(MyOnClick);
		mu.setOnClickListener(MyOnClick);
		point.setOnClickListener(MyOnClick);
		clear.setOnClickListener(MyOnClick);
	}

	private void init() {
		t1=(TextView) findViewById(R.id.t1);
		b0=(Button) findViewById(R.id.button0);
		b1=(Button) findViewById(R.id.button1);
		b2=(Button) findViewById(R.id.button2);
		b3=(Button) findViewById(R.id.button3);
		b4=(Button) findViewById(R.id.button4);
		b5=(Button) findViewById(R.id.button5);
		b6=(Button) findViewById(R.id.button6);
		b7=(Button) findViewById(R.id.button7);
		b8=(Button) findViewById(R.id.button8);
		b9=(Button) findViewById(R.id.button9);
		pl=(Button) findViewById(R.id.pl);
		eq=(Button) findViewById(R.id.eq);
		de=(Button) findViewById(R.id.de);
		s=(Button) findViewById(R.id.se);
		point=(Button) findViewById(R.id.point);
		mu=(Button) findViewById(R.id.mu);
		clear=(Button) findViewById(R.id.clear);
	}

	private Button.OnClickListener MyOnClick= new Button.OnClickListener () 
	{
		public void onClick(View v) 
		{
		String Str_Value;
		Str_Value=t1.getText().toString();
		switch (v.getId()){
		case R.id.button0:DisPlayNU("0");break;
		case R.id.button1:DisPlayNU("1");break;
		case R.id.button2:DisPlayNU("2");break;
		case R.id.button3:DisPlayNU("3");break;
		case R.id.button4:DisPlayNU("4");break;
		case R.id.button5:DisPlayNU("5");break;
		case R.id.button6:DisPlayNU("6");break;
		case R.id.button7:DisPlayNU("7");break;
		case R.id.button8:DisPlayNU("8");break;
		case R.id.button9:DisPlayNU("9");break;
		case R.id.point:DisPlayNU(".");break;			
	
		case R.id.pl:Calculate(0 , Str_Value);break;
		case R.id.se:Calculate(1 , Str_Value);break;
		case R.id.mu:Calculate(2 ,Str_Value);break;
		case R.id.de:Calculate(3 , Str_Value);break;
		case R.id.eq:Calculate(99 , "0");break;
		case R.id.clear:t1.setText("0");break;
		
		}
		}
	};

	private void DisPlayNU(String S)
	{
		String str;
		String Zero="0";
		str=t1.getText().toString();

		if ( Zero.equals(str)==true || Index_Value !=0)  
		{t1.setText("");
		t1.setText(S);			
		Index_Value=0;	}
		else
		{t1.setText(str+S);}
	}
	
	private void Calculate(int Cal_value , String Cal_Nu)
	{
		double x;
		String str_index;
		switch (Cal_value)
		{
		case 0:  
			NU1=Cal_Nu;
			Cal_index=0;
			t1.setText(""); break;
		case 1:  
			NU1=Cal_Nu;
			Cal_index=1;
			t1.setText(""); break;
		case 2:  
			NU1=Cal_Nu;
			Cal_index=2;
			t1.setText(""); break;
		case 3:  
			NU1=Cal_Nu;
			Cal_index=3;
			t1.setText(""); break;
		
		case 99:
			NU2=t1.getText().toString();
			double  i=Double.valueOf(NU1);
			double  j=Double.valueOf(NU2);
			switch(Cal_index)
			{
			case 0:
				x=i+j;
				str_index =Double.toString(x);
				t1.setText(str_index);
				break;
			case 1:
				x=i-j;
				str_index =Double.toString(x);
				t1.setText(str_index);	
				break;
			case 2:
				x=i*j;
				str_index =Double.toString(x);
				t1.setText(str_index);
				break;
			case 3:
				x=i/j;
				str_index =Double.toString(x);
				t1.setText(str_index);
				break;
			}
		break;
		}
	}

}
