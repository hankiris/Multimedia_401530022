/** Automatically generated file. DO NOT MODIFY */
package com.example.ca;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}