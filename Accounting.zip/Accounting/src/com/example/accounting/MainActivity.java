package com.example.accounting;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends Activity {

	ImageButton b,h,e;
	int bas=115,hour=40;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

	    Bundle bun=this.getIntent().getExtras();
	    try{
	    bas = bun.getInt("bas");
	    hour = bun.getInt("hour");
	    }catch(Exception w){
	    }
		init();
		setclick();

	}
	
	public void init(){
		b=(ImageButton) findViewById(R.id.imageButton1);
		h=(ImageButton) findViewById(R.id.imageButton2);
		e=(ImageButton) findViewById(R.id.imageButton3);
	}
	
	public void setclick(){
		b.setOnClickListener(M);
		h.setOnClickListener(M);
		e.setOnClickListener(M);
	}

	Button.OnClickListener M= new Button.OnClickListener () 
		{
			public void onClick(View v) 
			{
			Intent intent = new Intent();
		    Bundle bundle = new Bundle();
		    bundle.putInt("bas",bas );
		    bundle.putInt("hour", hour);
		    intent.putExtras(bundle);
			switch (v.getId()){
			case R.id.imageButton1:
				intent.setClass(MainActivity.this, Boss1.class);
				startActivity(intent); 
				MainActivity.this.finish();
				break;
			case R.id.imageButton2:
				intent.setClass(MainActivity.this, Hr1.class);
				startActivity(intent); 
				MainActivity.this.finish();
				break;
			case R.id.imageButton3:
				intent.setClass(MainActivity.this, Em.class);
				startActivity(intent); 
				MainActivity.this.finish();
				break;
			}
			}
		};
}
