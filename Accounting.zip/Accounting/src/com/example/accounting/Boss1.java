package com.example.accounting;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class Boss1  extends Activity {
	Button b;
	EditText e;
	TextView h,mo;
	int bas=0,hour=0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.boss1);
		init();
		setclick();
	    Bundle bun=this.getIntent().getExtras();
	    try{
	    bas = bun.getInt("bas");
	    hour = bun.getInt("hour");
	    e.setText(bas+"");
	    h.setText(hour+"  �p��");
		mo.setText(bas*hour+"$NTD");
		if(hour<30)
		h.setTextColor(Color.RED);
	    }catch(Exception w){
	    	
	    }
	}

	public void init(){
		b=(Button) findViewById(R.id.button1);
		e=(EditText)findViewById(R.id.editText1);
		h=(TextView)findViewById(R.id.hour);
		mo=(TextView)findViewById(R.id.Money);
		h.setText(hour+"  �p��");
	}
	
	public void setclick(){
		b.setOnClickListener(M);
        e.addTextChangedListener(new TextWatcher() {
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
		@Override
		public void beforeTextChanged(CharSequence s, int start, int count,
				int after) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			try{
    		bas=Integer.parseInt(e.getText().toString());
    		mo.setText(bas*hour+"$NTD");}
			catch(Exception w){}
		}});
	}

	Button.OnClickListener M= new Button.OnClickListener () 
		{
			public void onClick(View v) 
			{
			Intent intent = new Intent();
		    Bundle bundle = new Bundle();
		    bundle.putInt("bas",bas );
		    bundle.putInt("hour", hour);
		    intent.putExtras(bundle);
			intent.setClass(Boss1.this, MainActivity.class);
			startActivity(intent);
			Boss1.this.finish();
			}
		};
}
