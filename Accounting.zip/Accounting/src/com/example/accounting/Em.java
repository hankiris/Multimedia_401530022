package com.example.accounting;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class Em extends Activity {
	Button b;
	TextView ba,h,mo;
	int bas=0,hour=0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.employee);
		init();
		setclick();
	    Bundle bun=this.getIntent().getExtras();
	    try{
	    bas = bun.getInt("bas");
	    hour = bun.getInt("hour");
	    ba.setText(bas+"  /hr");
	    h.setText(hour+"  �p��");
		mo.setText(bas*hour+"$NTD");
		if(hour<30)
		h.setTextColor(Color.RED);
	    }catch(Exception w){
	    	
	    }
	}

	public void init(){
		b=(Button) findViewById(R.id.button1);
		h=(TextView)findViewById(R.id.textView5);
		mo=(TextView)findViewById(R.id.textView6);
		ba=(TextView)findViewById(R.id.textView4);
	}
	
	public void setclick(){
		b.setOnClickListener(M);
	}

	Button.OnClickListener M= new Button.OnClickListener () 
		{
			public void onClick(View v) 
			{
			Intent intent = new Intent();
		    Bundle bundle = new Bundle();
		    bundle.putInt("bas",bas );
		    bundle.putInt("hour", hour);
		    intent.putExtras(bundle);
			intent.setClass(Em.this, MainActivity.class);
			startActivity(intent);
			Em.this.finish();
			}
		};
}
