package com.example.accounting;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

public class Boss1  extends Activity {
	Button b;
	EditText e;
	TextView h,mo,all,toto;
	int bas=0,hour=0,spec=0,res=0;
	private Spinner sp;
	private ArrayAdapter<String> list;
	private String[] bonus= {"�L","�[�Z", "�`�y�[�Z", "�S���^�m"};


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.boss1);
		init();
		setclick();
	    Bundle bun=this.getIntent().getExtras();
	    try{
	    bas = bun.getInt("bas");
	    hour = bun.getInt("hour");
	    spec = bun.getInt("spec");
	    e.setText(bas+"");
	    h.setText(hour+"  �p��");
		mo.setText(bas*hour+"$NTD");
		result();
	    }catch(Exception w){
	    	
	    }
	}

	public void init(){
		b=(Button) findViewById(R.id.button1);
		e=(EditText) findViewById(R.id.editText1);
		h=(TextView) findViewById(R.id.hour);
		mo=(TextView) findViewById(R.id.Money);
		all=(TextView) findViewById(R.id.textView8);
		toto=(TextView) findViewById(R.id.textView10);
		h.setText(hour+"  �p��");
		sp=(Spinner)findViewById(R.id.spinner1); 
		list = new ArrayAdapter<String>(Boss1.this, android.R.layout.simple_spinner_item, bonus);                                     
		sp.setAdapter(list);
	}
	 
	public void setclick(){
		b.setOnClickListener(M);
        e.addTextChangedListener(new TextWatcher() {
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
		@Override
		public void beforeTextChanged(CharSequence s, int start, int count,
				int after) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			try{
    		bas=Integer.parseInt(e.getText().toString());
    		mo.setText(bas*hour+"$NTD");
    		result();
			}
			catch(Exception w){}
		}});
        
        //�U�԰�
        sp.setOnItemSelectedListener(new OnItemSelectedListener(){

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,int position, long arg3) {
               spec=position;
               result();
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            	spec=0;
            }
        });
	}

	
	public void result(){
		res=bas*hour;
		if(hour<130)
		h.setTextColor(Color.RED);
		if(hour>160){
		all.setText("+1000$");
	    res+=1000;
		}
		sp.setSelection(spec);
		switch(spec){
		case 0:
			break;
		case 1:
			res+=800;
			break;
		case 2:
			res+=1600;
			break;
		case 3:
			res+=500;
			break;
			}
		toto.setText(res+"$NTD");
	}
	
	
	Button.OnClickListener M= new Button.OnClickListener () 
		{
			public void onClick(View v) 
			{
			Intent intent = new Intent();
		    Bundle bundle = new Bundle();
		    bundle.putInt("bas",bas );
		    bundle.putInt("hour", hour);
		    bundle.putInt("spec",spec);
		    intent.putExtras(bundle);
			intent.setClass(Boss1.this, MainActivity.class);
			startActivity(intent);
			Boss1.this.finish();
			}
		};
}
