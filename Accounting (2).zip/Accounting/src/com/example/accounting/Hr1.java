package com.example.accounting;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class Hr1 extends Activity {

	Button b;
	EditText e;
	TextView h,mo,all,toto,sp;
	int bas=0,hour=0,res=0;
	int spec;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.hr);
	    Bundle bun=this.getIntent().getExtras();
		init();
		setclick();
	    try{
	    bas = bun.getInt("bas");
	    hour = bun.getInt("hour");
	    spec = bun.getInt("spec");
	    h.setText(bas+"  /hr");
	    e.setText(hour+"");
		mo.setText(bas*hour+"$NTD");
		switch(spec){
		case 0:
			sp.setText("�L+0");
			break;
		case 1:
			sp.setText("�[�Z+800");
			break;
		case 2:
			sp.setText("�`�y�[�Z+1600");
			break;
		case 3:
			sp.setText("�S���^�m+500");
			break;
			}
		result();
	    }catch(Exception w){
	    	
	    }
	}

	public void init(){
		b=(Button) findViewById(R.id.button1);
		e=(EditText)findViewById(R.id.editText1);
		h=(TextView)findViewById(R.id.textView4);
		mo=(TextView)findViewById(R.id.textView6);
		all=(TextView) findViewById(R.id.textView8);
		toto=(TextView) findViewById(R.id.textView10);
		sp=(TextView) findViewById(R.id.textView12);
		h.setText(hour+"  �p��");
	}
	
	public void setclick(){
		b.setOnClickListener(M);
        e.addTextChangedListener(new TextWatcher() {
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
		@Override
		public void beforeTextChanged(CharSequence s, int start, int count,
				int after) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			try{
    		hour=Integer.parseInt(e.getText().toString());
    		mo.setText(hour*bas+"$NTD");
    		result();}
			catch(Exception w){}
		}});
	}

	Button.OnClickListener M= new Button.OnClickListener () 
		{
			public void onClick(View v) 
			{
			Intent intent = new Intent();
		    Bundle bundle = new Bundle();
		    bundle.putInt("bas",bas );
		    bundle.putInt("hour", hour);
		    bundle.putInt("spec",spec);
		    intent.putExtras(bundle);
			intent.setClass(Hr1.this, MainActivity.class);
			startActivity(intent); 
			Hr1.this.finish();
			}
		};

		public void result(){
			res=bas*hour;
			if(hour>160){
			all.setText("+1000$");
		    res+=1000;
			}
			switch(spec){
			case 0:
				break;
			case 1:
				res+=800;
				break;
			case 2:
				res+=1600;
				break;
			case 3:
				res+=500;
				break;
				}
			toto.setText(res+"$NTD");
		}

}
